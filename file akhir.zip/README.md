# 🗂️ Pekerja Lepas — Panduan Deploy

Aplikasi pencatat waktu pekerjaan untuk freelancer.  
Backend: **Google Apps Script + Google Sheets**  
Frontend: **HTML/CSS/JS** → host di GitHub Pages atau Netlify (gratis)

---

## 📁 Struktur File

```
pekerja-lepas/
├── Code.gs        ← Paste ke Google Apps Script
├── api.js         ← Konfigurasi URL Apps Script
├── auth.js        ← Logika login & session
├── login.html     ← Halaman login (buka ini pertama)
├── index.html     ← Dashboard user
├── admin.html     ← Panel admin
├── app.js         ← Logika fitur user
├── style.css      ← Styling global
└── README.md      ← Panduan ini
```

---

## ⚙️ LANGKAH 1 — Setup Google Sheets & Apps Script

### 1.1 Buat Spreadsheet

1. Buka [sheets.google.com](https://sheets.google.com)
2. Klik **+ Blank spreadsheet**
3. Beri nama: **"DB Pekerja Lepas"** (bebas)

### 1.2 Buka Apps Script

1. Di spreadsheet → menu **Extensions → Apps Script**
2. Hapus semua kode default di editor
3. Copy seluruh isi file `Code.gs` → paste ke editor
4. Klik ikon 💾 **Save** (Ctrl+S)

### 1.3 Inisialisasi Sheet otomatis

1. Di Apps Script, pastikan fungsi yang dipilih adalah **`initSheets`**  
   *(dropdown di toolbar, default biasanya `myFunction` — ganti ke `initSheets`)*
2. Klik tombol ▶️ **Run**
3. Akan muncul popup izin akses Google → klik **Review permissions → Allow**
4. Setelah selesai, buka spreadsheet → akan ada 2 sheet baru: **Users** dan **Pekerjaan**
5. Sheet **Users** sudah terisi 3 akun default:

   | username | password | role  |
   |----------|----------|-------|
   | admin    | admin123 | admin |
   | user1    | user123  | user  |
   | user2    | user456  | user  |

> ⚠️ **Ganti password** akun setelah pertama kali masuk!

### 1.4 Deploy sebagai Web App

1. Klik **Deploy** (pojok kanan atas) → **New deployment**
2. Klik ⚙️ di sebelah "Select type" → pilih **Web app**
3. Isi pengaturan:
   - **Description**: `Pekerja Lepas API v1`
   - **Execute as**: `Me (email kamu)`
   - **Who has access**: `Anyone` ← **wajib ini agar bisa diakses dari luar**
4. Klik **Deploy** → muncul popup izin → **Allow**
5. Copy **Web App URL** yang muncul. Contoh:
   ```
   https://script.google.com/macros/s/AKfycbXXXXXXXXXXX/exec
   ```
6. Simpan URL ini — akan dipakai di langkah berikutnya

> ⚠️ **Penting:** Setiap kali kamu edit `Code.gs`, kamu harus buat **deployment baru** lagi  
> (Deploy → New deployment). Jangan "update" deployment lama karena Apps Script cache versi lama.

---

## ⚙️ LANGKAH 2 — Pasang URL ke api.js

Buka file `api.js`, cari baris ini:

```js
const API_URL = 'GANTI_DENGAN_URL_APPS_SCRIPT_KAMU';
```

Ganti dengan URL dari langkah 1.4:

```js
const API_URL = 'https://script.google.com/macros/s/AKfycbXXXXX/exec';
```

Simpan file.

---

## 🌐 LANGKAH 3A — Deploy ke GitHub Pages (Gratis)

GitHub Pages cocok untuk file statis HTML/CSS/JS.

### 3A.1 Buat akun GitHub

Kalau belum punya, daftar di [github.com](https://github.com)

### 3A.2 Buat repository baru

1. Klik **+** → **New repository**
2. Nama repo: `pekerja-lepas` (atau bebas)
3. Visibility: **Public** *(GitHub Pages gratis hanya untuk public)*
4. Klik **Create repository**

### 3A.3 Upload semua file

**Cara mudah (drag & drop):**
1. Di halaman repo → klik **uploading an existing file**
2. Drag semua file (kecuali `Code.gs` dan `README.md`) ke kotak upload:
   - `login.html`
   - `index.html`
   - `admin.html`
   - `api.js`
   - `auth.js`
   - `app.js`
   - `style.css`
3. Scroll bawah → klik **Commit changes**

### 3A.4 Aktifkan GitHub Pages

1. Di repo → **Settings** → scroll ke **Pages** (menu kiri)
2. Di **Source** → pilih **Deploy from a branch**
3. Branch: **main**, folder: **/ (root)**
4. Klik **Save**
5. Tunggu 1-2 menit → URL akan muncul:
   ```
   https://USERNAME.github.io/pekerja-lepas/login.html
   ```

✅ Aplikasi sudah online! Bagikan URL tersebut ke user.

---

## 🌐 LANGKAH 3B — Deploy ke Netlify (Alternatif, lebih mudah)

### Cara drag & drop (tanpa akun GitHub):

1. Buka [app.netlify.com](https://app.netlify.com) → daftar/login
2. Di dashboard → scroll ke bawah → ada kotak **"Want to deploy a new site without connecting to Git?"**
3. Buka folder `pekerja-lepas` di File Explorer / Finder
4. **Drag & drop seluruh folder** ke kotak tersebut
5. Tunggu beberapa detik → URL langsung jadi, contoh:
   ```
   https://magical-name-123.netlify.app/login.html
   ```
6. Bisa ganti nama domain di **Site settings → Domain management**

✅ Selesai. Netlify juga support HTTPS otomatis.

---

## 🔄 CARA UPDATE APLIKASI

### Jika update file HTML/JS/CSS:
- **GitHub Pages**: Upload ulang file yang berubah → commit → otomatis deploy dalam 1-2 menit
- **Netlify**: Drag & drop folder lagi → otomatis replace

### Jika update Code.gs (backend):
1. Edit kode di Apps Script
2. **Deploy → New deployment** (bukan edit yang lama!)
3. Copy URL baru → update `api.js` → upload ulang `api.js`

---

## 🔐 Tips Keamanan

- **Ganti password default** setelah pertama deploy
- Jangan share URL Apps Script secara publik tanpa enkripsi tambahan
- Untuk produksi skala besar, pertimbangkan tambah token autentikasi di setiap request
- Password di Sheets tersimpan plaintext — untuk keamanan lebih, tambah hashing (bcrypt via library GAS)

---

## 🛠️ Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Login gagal "Gagal terhubung ke server" | Cek `API_URL` di `api.js`, pastikan URL Apps Script benar |
| Data tidak muncul | Buka DevTools (F12) → Console → lihat error detail |
| Apps Script error "Sheet tidak ditemukan" | Jalankan ulang fungsi `initSheets` di Apps Script |
| GitHub Pages tidak update | Tunggu 2-3 menit, atau coba hard refresh (Ctrl+Shift+R) |
| CORS error di browser | Pastikan deployment Apps Script di-set **"Who has access: Anyone"** |
| "TypeError: Failed to fetch" | Cek apakah URL Apps Script masih aktif, coba buka URL-nya langsung di browser |

---

## 📞 Akun Default

| Username | Password | Role  | Akses |
|----------|----------|-------|-------|
| admin    | admin123 | Admin | Semua fitur + kelola user |
| user1    | user123  | User  | Dashboard & pekerjaan sendiri |
| user2    | user456  | User  | Dashboard & pekerjaan sendiri |

> Tambah user baru via panel Admin → menu **Kelola User → Tambah User**
